<?php
// Text
$_['text_cookie'] = 'This website uses cookies for more information <a href="%s" class="alert-link agree">click here</a>.';
//We use cookies to improve our site and your experience. By continuing to browse our site you accept our cookie policy Find out more

// Button
$_['button_close'] = 'Close';